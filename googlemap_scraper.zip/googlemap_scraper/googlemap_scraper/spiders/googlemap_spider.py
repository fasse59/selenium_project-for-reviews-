import csv
import re
import scrapy
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementNotInteractableException, \
    ElementClickInterceptedException, StaleElementReferenceException


class GoogleBusinessSpider(scrapy.Spider):
    name = 'googlemap_spider'
    start_urls = ['http://www.google.com/']

    custom_settings = {
        'FEED_URI': 'Business_data_output.csv',
        'FEED_FORMAT': 'csv',
        'FEED_FORMAT_ENCODING': 'utf-8-sig',
    }

    def __init__(self):
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.maximize_window()

    def start_requests(self):
        yield scrapy.Request(url='https://example.com/', callback=self.parse)

    def parse(self, response, **kwargs):
        input_list = self.get_data_from_file()
        for input_data in input_list:
            self.driver.get(input_data['urls'])
            self.driver.implicitly_wait(5)
            try:
                response = scrapy.Selector(text=self.driver.page_source)

                input_data['Business_name'] = response.xpath("//h1[@class = 'DUwDvf lfPIob']/text()").get('')
                ad = response.xpath('//button[@data-item-id="address"]/@aria-label').get('')
                if ad:
                    input_data['Primary_Address'] = ad.replace('Address:', '').strip()
                else:
                    input_data['Primary_Address'] = ''
                plus_code = response.xpath("//button[@data-tooltip='Copy plus code']/@aria-label").get()
                if plus_code:
                    input_data['secondry Address'] = plus_code.replace('Plus code:', '').strip()
                else:
                    input_data['secondry Address'] = ''

                phone_label = response.xpath("//button[@data-tooltip='Copy phone number']/@aria-label").get()
                if phone_label:
                    input_data['contact_number'] = phone_label.replace('Phone: ', '').strip()
                else:
                    input_data['contact_number'] = ''

                input_data['website'] = response.xpath("//a[@data-item-id='authority']/@href").get('')

                try:
                    reviews_btn = self.driver.find_element(By.XPATH,
                                                           "//div[contains(@class,'Gpq6kf fontTitleSmall')][text()='Reviews']")
                    reviews_btn.click()
                    time.sleep(2)
                except (NoSuchElementException, TimeoutException) as e:
                    print(f"Error finding or clicking Reviews button: {e}")
                    continue

                response = scrapy.Selector(text=self.driver.page_source)
                input_data['rating'] = response.css(".jANrlb .fontDisplayLarge::text").get('')
                reviews_text = response.xpath(
                    "//div[@class='jANrlb ']//div[@class='fontBodySmall'][contains(text(),'reviews')]/text()").get()
                if reviews_text:
                    input_data['available reviews'] = reviews_text.replace('reviews', '').strip()
                else:
                    input_data['available reviews'] = ''

                no_of_reviews = int(re.findall(r'\d+', input_data['available reviews'])[0]) if re.findall(r'\d+',
                                                                                                          input_data[
                                                                                                              'available reviews']) else 0
                i = 0

                while i < no_of_reviews:
                    self.driver.find_element(By.CSS_SELECTOR, '[aria-label="Write a review"]').send_keys(Keys.END)

                    try:
                        WebDriverWait(self.driver, 10).until(
                            lambda driver: len(driver.find_elements(By.CSS_SELECTOR, '.m6QErb .jftiEf')) > i
                        )
                    except TimeoutException:
                        print("Timed out waiting for more reviews to load.")
                        break

                    i = len(self.driver.find_elements(By.CSS_SELECTOR, '.m6QErb .jftiEf'))

                    if i >= no_of_reviews:
                        break

                reviews_check = self._is_exist_selector(driver=self.driver, css='.m6QErb .jftiEf')
                if reviews_check:
                    reviews_dict = self.driver.find_elements(By.CSS_SELECTOR, '.m6QErb .jftiEf')
                    for review in reviews_dict:
                        more_content_btn = self._is_exist_selector(driver=review,
                                                                   css='.w8nwRe[aria-label="See more"]')
                        if more_content_btn:
                            review.find_element(By.CSS_SELECTOR, '.w8nwRe[aria-label="See more"]').click()
                        review_html = review.get_attribute('outerHTML')
                        review_response = scrapy.Selector(text=review_html)

                        input_data["reviewer"] = review_response.css(".jJc9Ad .d4r55::text").get('')
                        input_data['review_time'] = review_response.css(".jJc9Ad .xRkPPb::text").get('')
                        input_data['review_date'] = review_response.css(".jJc9Ad .fzvQIb::text").get('')
                        input_data['review_text'] = review_response.css(".MyEned .wiI7pd::text").get('')

                        yield input_data
                else:
                    yield input_data
            except Exception as e:
                print(f"An error occurred: {e}")
                continue
        self.driver.quit()

    def get_data_from_file(self):
        with open(file='Business_input (2).csv', mode='r', encoding='utf-8') as input_file:
            csv_reader = csv.DictReader(input_file)
            return list(csv_reader)

    def _is_exist_selector(self, driver=None, css='', xpath='', timeout=30):
        try:
            if css:
                WebDriverWait(driver or self.driver, timeout=timeout).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, css)))
            elif xpath:
                WebDriverWait(driver or self.driver, timeout=timeout).until(
                    EC.presence_of_element_located((By.XPATH, xpath)))
            return True
        except (NoSuchElementException, TimeoutException, ElementNotInteractableException,
                ElementClickInterceptedException, StaleElementReferenceException):
            return False

    def close(self, reason):
        self.driver.quit()
